
#include "physics.hpp"
#include "io.hpp"
#include "utils.hpp"
#include <cmath>
#include <fstream>
#include <filesystem>
#include <iomanip>
#include <algorithm>

namespace physics {

// --- Minimal pieces reused from previous steps (stubs for context) ---
static inline double driveV(const Circuit& c, double t){ if (c.shape=="pulse"){ return (t<=c.t_pulse)?c.V0:0.0; } return c.V0; }
void solve_LR(const Circuit& c, double t_end, double dt, const std::string& out_dir){
    namespace fs = std::filesystem; fs::create_directories(out_dir + "/debug");
    std::ofstream f(out_dir + "/debug/0d_circuit.csv"); f << "t,I,V,dI_dt\n";
    double I=0.0; for(double t=0.0;t<=t_end+1e-16;t+=dt){ double V=driveV(c,t);
        double k1=(V-c.R*I)/c.L, Ipred=I+dt*k1; double V2=driveV(c,t+dt);
        double k2=(V2-c.R*Ipred)/c.L; double dI=0.5*dt*(k1+k2); I+=dI;
        f<<std::setprecision(16)<<t<<","<<I<<","<<V<<","<<(dI/dt)<<"\n"; }
}

// simple equilibrium builder: keep Bθ from current and set p via radial balance
static void build_Btheta_profile(const Fields& F, const RunConfig& cfg, const Equilibrium& eq, std::vector<double>& Bth){
    const auto& g=F.g; const size_t Nr=g.Nr; const size_t Ng=g.Ng; const size_t Nt=g.size_r();
    Bth.assign(Nt,0.0);
    auto Jz = [&](double r){ if (eq.type=="bennett"){ double a=std::max(1e-12, eq.a*g.Rmax); double x=r/a; return 1.0/std::pow(1+x*x,2.0);} 
                             double r0=eq.r0*g.Rmax; double w=0.05*g.Rmax; return 0.5*(1.0-std::tanh((r-r0)/w)); };
    double dr=g.dr, Itot=0; std::vector<double> J(Nr,0.0);
    for(size_t ip=0; ip<Nr; ++ip){ size_t i=Ng+ip; double r=(int(i)-int(Ng)+0.5)*dr; if(r<=0){J[ip]=0;continue;} J[ip]=Jz(r); Itot += J[ip]*r*dr; }
    double scale=(Itot>0)? (eq.I0/Itot):0; for(double&v:J)v*=scale;
    double Ienc=0; for(size_t ip=0; ip<Nr; ++ip){ size_t i=Ng+ip; double r=(int(i)-int(Ng)+0.5)*dr; if(r<=0){Bth[i]=0;continue;} Ienc+=J[ip]*r*dr; Bth[i]=Ienc/r; }
    for(size_t i=0;i<Ng;++i) Bth[i]=Bth[Ng]; for(size_t i=Ng+Nr;i<Nt;++i) Bth[i]=Bth[Ng+Nr-1];
}
void build_equilibrium(Fields& F, const RunConfig& cfg, const Equilibrium& eq){
    const auto& g=F.g; const size_t Nr=g.Nr; const size_t Ng=g.Ng;
    namespace fs=std::filesystem; fs::create_directories(cfg.out_dir + "/debug");
    std::vector<double> Bth; build_Btheta_profile(F,cfg,eq,Bth);
    std::vector<double> rhs(g.size_r(),0.0), p(g.size_r(),0.0); p[Ng]=eq.p0;
    for(size_t ip=Ng; ip<Ng+Nr; ++ip){
        double r=(int(ip)-int(Ng)+0.5)*g.dr; double dB=0.0;
        if(ip==Ng) dB=(Bth[ip+1]-Bth[ip])/g.dr;
        else if(ip==Ng+Nr-1) dB=(Bth[ip]-Bth[ip-1])/g.dr;
        else dB=(Bth[ip+1]-Bth[ip-1])/(2.0*g.dr);
        double r_safe=(r>1e-14? r:1e-14);
        rhs[ip]=-( Bth[ip]*dB + (Bth[ip]*Bth[ip])/r_safe );
        if(ip>Ng) p[ip]=p[ip-1]+0.5*(rhs[ip-1]+rhs[ip])*g.dr;
    }
    for(size_t i=0;i<Ng;++i) p[i]=p[Ng];
    for(size_t i=Ng+Nr;i<g.size_r();++i) p[i]=p[Ng+Nr-1];
    for(size_t i=0;i<g.size_r();++i){
        for(size_t k=0;k<g.size_z();++k){
            size_t id=g.idx(i,k);
            F.rho[id]=eq.rho0; F.p[id]=p[i]; F.Bz[id]=cfg.phys.Bz0; F.Bth[id]=Bth[i];
            F.Br[id]=0.0; F.vr[id]=F.vz[id]=F.vth[id]=0.0;
        }
    }
}

void initialize(Fields& F, const RunConfig& cfg){
    const auto& g=F.g;
    for(size_t i=0;i<g.size_r();++i){
        for(size_t k=0;k<g.size_z();++k){
            size_t id=g.idx(i,k);
            F.rho[id]=1.0; F.p[id]=1e-2; F.Bz[id]=cfg.phys.Bz0; F.Bth[id]=0.0;
            F.Br[id]=0.0; F.vr[id]=F.vz[id]=F.vth[id]=0.0;
        }
    }
}
void apply_sources(Fields&, const RunConfig&, double){}
double max_wavespeed(const Fields&, const RunConfig&){ return 1.0; }

// ===================== 2D CT toy =====================
// We evolve (Br, Bz) via induction: ∂B/∂t = -∇×E, with Eθ = v_r B_z - v_z B_r
// Bθ is left untouched here (acts like toroidal field). Velocities are synthetic.

static inline double clamp(double x, double a, double b){ return std::min(b, std::max(a,x)); }

void run_2d_ct(Fields& F, const RunConfig& cfg, const CTConfig& ctcfg){
    const auto& g = F.g;
    namespace fs=std::filesystem; fs::create_directories(cfg.out_dir + "/debug");

    // Synthetic velocity field
    auto vel = [&](double r, double z){
        double vr=0.0, vz=0.0;
        if (ctcfg.vel_type=="solid"){
            // vz ~ a * r  (shear in z with radius)
            vz = ctcfg.vel_amp * r / std::max(1e-12, g.Rmax);
            vr = 0.0;
        } else { // "shear": vz ~ a * sin(pi z / Zmax)
            vz = ctcfg.vel_amp * std::sin(M_PI * z / std::max(1e-12, g.Zmax));
            vr = 0.0;
        }
        return std::pair<double,double>(vr, vz);
    };

    // time step from advective CFL-like (toy)
    double vmax = std::max(1e-12, ctcfg.vel_amp);
    double dt = cfg.cfl * std::min(g.dr, g.dz) / vmax;
    dt = std::min(dt, cfg.t_end); // be safe

    // create/clear metrics file
    { std::ofstream(cfg.out_dir + "/debug/2d_ct_metrics.csv") << "t,divB_L2,Emag\n"; }

    double t=0.0;
    int step=0;
    while (t < cfg.t_end - 1e-16){
        // EMF at cell corners (i+1/2, k+1/2)
        std::vector<double> E(g.size_r()*g.size_z(), 0.0);
        auto Eidx = [&](size_t i, size_t k){ return g.idx(i,k); };

        for (size_t i=1; i<g.size_r()-1; ++i){
            for (size_t k=1; k<g.size_z()-1; ++k){
                double r = (int(i)-int(g.Ng)+0.0)*g.dr;   // corner ~ r_i
                double z = (int(k)-int(g.Ng)+0.0)*g.dz;   // corner ~ z_k
                auto [vr, vz] = vel(r, z);
                // average Br and Bz from surrounding centers (simple bilinear)
                double Brc = 0.25*(F.Br[g.idx(i,k)] + F.Br[g.idx(i-1,k)] + F.Br[g.idx(i,k-1)] + F.Br[g.idx(i-1,k-1)]);
                double Bzc = 0.25*(F.Bz[g.idx(i,k)] + F.Bz[g.idx(i-1,k)] + F.Bz[g.idx(i,k-1)] + F.Bz[g.idx(i-1,k-1)]);
                double Etheta = vr * Bzc - vz * Brc;
                // optional resistive damping term: -eta Jθ ≈ -eta (∂Br/∂z - ∂Bz/∂r)
                if (ctcfg.resistivity > 0){
                    double dBr_dz = (F.Br[g.idx(i,k)] - F.Br[g.idx(i,k-1)]) / g.dz;
                    double dBz_dr = (F.Bz[g.idx(i,k)] - F.Bz[g.idx(i-1,k)]) / g.dr;
                    Etheta += - ctcfg.resistivity * (dBr_dz - dBz_dr);
                }
                E[Eidx(i,k)] = Etheta;
            }
        }

        // Update B using CT-like curl of E
        // Br^{n+1} = Br^n - dt * ∂E/∂z  ;  Bz^{n+1} = Bz^n + dt * ∂E/∂r
        std::vector<double> Br_new(F.Br), Bz_new(F.Bz);
        for (size_t i=1; i<g.size_r()-1; ++i){
            for (size_t k=1; k<g.size_z()-1; ++k){
                double dE_dz = (E[Eidx(i,k+1)] - E[Eidx(i,k)]) / g.dz; // forward at lower edge
                double dE_dr = (E[Eidx(i+1,k)] - E[Eidx(i,k)]) / g.dr;
                Br_new[g.idx(i,k)] = F.Br[g.idx(i,k)] - dt * dE_dz;
                Bz_new[g.idx(i,k)] = F.Bz[g.idx(i,k)] + dt * dE_dr;
            }
        }

        // Copy back and apply simple BCs (zero-gradient at boundaries)
        F.Br.swap(Br_new); F.Bz.swap(Bz_new);
        for (size_t k=0;k<g.size_z();++k){
            F.Br[g.idx(g.Ng,k)] = F.Br[g.idx(g.Ng+1,k)];
            F.Br[g.idx(g.size_r()-g.Ng-1,k)] = F.Br[g.idx(g.size_r()-g.Ng-2,k)];
            F.Bz[g.idx(g.Ng,k)] = F.Bz[g.idx(g.Ng+1,k)];
            F.Bz[g.idx(g.size_r()-g.Ng-1,k)] = F.Bz[g.idx(g.size_r()-g.Ng-2,k)];
        }
        for (size_t i=0;i<g.size_r();++i){
            F.Br[g.idx(i,g.Ng)] = F.Br[g.idx(i,g.Ng+1)];
            F.Br[g.idx(i,g.size_z()-g.Ng-1)] = F.Br[g.idx(i,g.size_z()-g.Ng-2)];
            F.Bz[g.idx(i,g.Ng)] = F.Bz[g.idx(i,g.Ng+1)];
            F.Bz[g.idx(i,g.size_z()-g.Ng-1)] = F.Bz[g.idx(i,g.size_z()-g.Ng-2)];
        }

        t += dt; step++;
        if (step % cfg.output_every == 0){
            io::write_snapshot(F, cfg, step, t);
            double divB = utils::divB_L2(F);
            double Emag = 0.0;
            for (size_t i=0;i<g.size_r();++i){
                for (size_t k=0;k<g.size_z();++k){
                    size_t id=g.idx(i,k);
                    Emag += 0.5*(F.Br[id]*F.Br[id] + F.Bz[id]*F.Bz[id] + F.Bth[id]*F.Bth[id]);
                }
            }
            std::ofstream(cfg.out_dir + "/debug/2d_ct_metrics.csv", std::ios::app)
                << std::setprecision(16) << t << "," << divB << "," << Emag << "\n";
            utils::DebugFrame dbg;
            dbg.t=t; dbg.dt=dt; dbg.cfl=cfg.cfl; dbg.max_wave=0.0;
            dbg.divB_L2_val=divB; dbg.energy_tot=Emag; dbg.nan_count=utils::count_nans(F);
            dbg.notes="2D_CT checkpoint"; dbg.write_json(cfg.out_dir, step);
        }
    }
}

} // namespace physics
