
#pragma once
#include "state.hpp"
#include <string>

namespace physics {

struct Circuit { double L{1.0}; double R{1.0}; double V0{1.0}; std::string shape{"step"}; double t_pulse{0.0}; };
void solve_LR(const Circuit& c, double t_end, double dt, const std::string& out_dir);

struct Equilibrium { std::string type{"bennett"}; double I0{0.15}; double r0{0.25}; double a{0.35}; double p0{1e-2}; double rho0{1.0}; };
void build_equilibrium(Fields& F, const RunConfig& cfg, const Equilibrium& eq);

struct RadialBC { std::string axis{"regular"}; std::string wall{"conducting"}; bool clamp_Bz_at_wall{false}; };
struct Resistivity { double eta0{1e-6}; double eta_wall_mult{1.0}; double r_wall_frac{0.9}; };

void step_1d_r(Fields& F, const RunConfig& cfg, double& t, double dt, const RadialBC& bc, const Resistivity& rp, bool write_metrics);

// ---- Step 3: 2D (r,z) CT toy induction solver ----
struct CTConfig {
    double vel_amp{0.0};   // amplitude for a synthetic velocity field
    std::string vel_type{"solid"}; // "solid" (vz ~ ar, vr ~ 0) or "shear" (vr ~ 0, vz ~ sin)
    double resistivity{0.0}; // optional eta for EMF damping (0 => ideal)
};
void run_2d_ct(Fields& F, const RunConfig& cfg, const CTConfig& ctcfg);

// legacy
void initialize(Fields& F, const RunConfig& cfg);
void apply_sources(Fields& F, const RunConfig& cfg, double dt);
double max_wavespeed(const Fields& F, const RunConfig& cfg);

} // namespace physics
