
#include "io.hpp"
#include <fstream>
#include <filesystem>
#include <iomanip>

namespace io {

static void write_csv_vec(std::ofstream& f, const std::vector<double>& v){
    for(size_t i=0;i<v.size();++i){
        f << v[i] << (i+1==v.size()? '\n' : ',');
    }
}

void write_snapshot(const Fields& F, const RunConfig& cfg, int step, double t){
    std::filesystem::create_directories(cfg.out_dir);
    std::string base = cfg.out_dir + "/fields_" + std::to_string(step);
    // Very simple CSV bundles per field for quick hacking
    {
        std::ofstream f(base + "_rho.csv"); write_csv_vec(f, F.rho);
    }{
        std::ofstream f(base + "_p.csv"); write_csv_vec(f, F.p);
    }
    // Extend with other fields as needed
    std::ofstream meta(base + "_meta.txt");
    meta << "t=" << std::setprecision(16) << t << "\n";
    meta << "Nr=" << F.g.Nr << ", Nz=" << F.g.Nz << ", Ng=" << F.g.Ng << "\n";
    meta << "Rmax=" << F.g.Rmax << ", Zmax=" << F.g.Zmax << "\n";
}

void write_diag(const std::string& out_dir, int step, double t, double max_c){
    std::filesystem::create_directories(out_dir);
    std::ofstream f(out_dir + "/diag.csv", std::ios::app);
    if (step==0) f << "step,t,max_c\n";
    f << step << "," << std::setprecision(16) << t << "," << max_c << "\n";
}

}
