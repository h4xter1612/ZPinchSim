
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>

#include "grid.hpp"
#include "state.hpp"
#include "physics.hpp"
#include "time_integrator.hpp"
#include "io.hpp"

// ultra-minimal YAML-ish parser for this scaffold (avoids deps)
static std::string slurp(const std::string& path){
    std::ifstream f(path); std::stringstream ss; ss << f.rdbuf(); return ss.str();
}
static double read_val(const std::string& s, const std::string& key, double def){
    auto p = s.find(key + ":"); if (p==std::string::npos) return def;
    auto e = s.find("\n", p); std::string line = s.substr(p, e-p);
    auto c = line.find(":"); return std::stod(line.substr(c+1));
}
static int read_ival(const std::string& s, const std::string& key, int def){
    return (int)read_val(s, key, def);
}
static std::string read_sval(const std::string& s, const std::string& key, const std::string& def){
    auto p = s.find(key + ":"); if (p==std::string::npos) return def;
    auto c = s.find(":", p); auto e = s.find("\n", p);
    std::string v = s.substr(c+1, e-c-1);
    // trim
    size_t a=v.find_first_not_of(" \t"); size_t b=v.find_last_not_of(" \t");
    if (a==std::string::npos) return def; return v.substr(a, b-a+1);
}

int main(int argc, char** argv){
    if (argc<2){ std::cerr << "Usage: zpinch_run <config.yaml>\n"; return 1; }
    std::string cfgs = slurp(argv[1]);

    // Read a few keys (scaffold)
    int Nr = read_ival(cfgs, "Nr", 64);
    int Nz = read_ival(cfgs, "Nz", 128);
    int Ng = read_ival(cfgs, "ghost", 3);
    double Rmax = read_val(cfgs, "Rmax", 0.01);
    double Zmax = read_val(cfgs, "Zmax", 0.10);
    double t_end = read_val(cfgs, "t_end", 1e-6);
    double cfl = read_val(cfgs, "cfl", 0.4);
    double dt_min = read_val(cfgs, "dt_min", 1e-12);
    std::string out_dir = read_sval(cfgs, "out_dir", "../data");

    Grid g(Nr, Nz, Ng, Rmax, Zmax);
    RunConfig rc{g, {}, t_end, cfl, dt_min, 50, out_dir};

    Fields F(g);
    physics::initialize(F, rc);

    double t=0.0; int step=0;
    while (t < rc.t_end){
        double max_c = physics::max_wavespeed(F, rc);
        double dt = std::max(rc.dt_min, rc.cfl * std::min(g.dr, g.dz) / (max_c+1e-12));
        timeint::step(F, rc, t, dt);
        t += dt; step++;
        if (step % rc.output_every == 0){
            io::write_snapshot(F, rc, step, t);
            io::write_diag(rc.out_dir, step, t, max_c);
            std::cout << "t=" << t << " step=" << step << " dt=" << dt << "\n";
        }
    }
    // final dump
    io::write_snapshot(F, rc, step, t);
    io::write_diag(rc.out_dir, step, t, physics::max_wavespeed(F, rc));
    std::cout << "Done at t=" << t << " after " << step << " steps.\n";
    return 0;
}
