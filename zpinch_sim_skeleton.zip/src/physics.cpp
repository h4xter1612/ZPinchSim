
#include "physics.hpp"
#include <cmath>
#include <random>

namespace physics {

void initialize(Fields& F, const RunConfig& cfg) {
    // Simple tophat current channel with background; Bz0 constant
    const auto& g = F.g;
    double r0 = 0.25 * g.Rmax;
    for (size_t i=0;i<g.size_r();++i){
        double r = (int(i)-int(g.Ng)+0.5)*g.dr;
        for (size_t k=0;k<g.size_z();++k){
            size_t id = g.idx(i,k);
            F.rho[id] = (r<r0) ? 1.0 : 0.2;
            F.p[id]   = (r<r0) ? 1e-2 : 5e-3;
            F.Bz[id]  = cfg.phys.Bz0;
            // crude Btheta profile to mimic pinch current ~ r for small r
            F.Bth[id] = (r<r0) ? r/r0 : r0/r;
        }
    }
}

void apply_sources(Fields& F, const RunConfig& cfg, double /*dt*/) {
    // TODO: cylindrical sources and resistive terms
    (void)F; (void)cfg;
}

double max_wavespeed(const Fields& F, const RunConfig& /*cfg*/) {
    // Placeholder: returns a constant for now
    (void)F;
    return 1.0;
}

} // namespace physics
