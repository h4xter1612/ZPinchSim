
#pragma once
#include "state.hpp"

namespace riemann {
// Compute numerical fluxes (placeholder HLL skeleton)
void flux_r(const Fields& F, Fields& dU, const RunConfig& cfg);
void flux_z(const Fields& F, Fields& dU, const RunConfig& cfg);
}
