
#pragma once
#include "state.hpp"

namespace physics {
// Initialize equilibrium and seed perturbations
void initialize(Fields& F, const RunConfig& cfg);
// Apply cylindrical source terms near r=0 and wall BCs
void apply_sources(Fields& F, const RunConfig& cfg, double dt);
// Compute max wavespeed (very rough placeholder)
double max_wavespeed(const Fields& F, const RunConfig& cfg);
}
