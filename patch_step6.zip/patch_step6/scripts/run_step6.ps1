# run_step6.ps1 - ejemplo
param(
  [string]$Exe = ".\zpinch_run.exe",
  [string]$Template = "..\configs\templates\run2d_modes_template.yaml",
  [string]$OutRoot = ".\data_runs\Bz_sweep",
  [string]$Bzs = "0.05,0.1,0.2,0.5,1,2"
)
python ..\viz\step6_sweep_modes.py --exe $Exe --template $Template --out-root $OutRoot --bzs $Bzs
