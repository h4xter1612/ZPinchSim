# Patch Step6

- C++: nuevos knobs `vmax_guard`, `dt_max`, `diag_every`, logging de `vmax_raw`/`vmax`/`dt` y escritura regular de `diag.csv`.
- Python: barrido `step6_sweep_modes.py` y core `_modes_core.py` con `fit_frac`.
- Plantilla YAML con `${Bz0}` y `${OUT}` para generar múltiples corridas sin sobrescribir.

## Build
```
cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . --config Release
```

## Ejecutar barrido (desde build/Release)
```
.\scriptsun_step6.ps1 -Exe .\zpinch_run.exe -Template ..\configs	emplatesun2d_modes_template.yaml -OutRoot .\data_runs\Bz_sweep -Bzs "0.1,0.2,0.5,1,2"
```

o directamente:
```
python ..iz\step6_sweep_modes.py --exe .\zpinch_run.exe --template ..\configs	emplatesun2d_modes_template.yaml --out-root .\data_runs\Bz_sweep --bzs 0.1,0.2,0.5,1,2
```
