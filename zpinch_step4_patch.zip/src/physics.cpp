#include "physics.hpp"
#include "riemann.hpp"
#include "reconstruction.hpp"
#include "io.hpp"
#include "utils.hpp"
#include <vector>
#include <cmath>
#include <fstream>
#include <filesystem>
#include <iomanip>
#include <algorithm>

namespace physics {

static void init_problem(Fields& F, const RunConfig& cfg, const MHD2DConfig& mhd){
    const auto& g = F.g;
    for (size_t i=0;i<g.size_r();++i){
        double r = (int(i)-int(g.Ng)+0.5)*g.dr;
        for (size_t k=0;k<g.size_z();++k){
            double z = (int(k)-int(g.Ng)+0.5)*g.dz;
            size_t id = g.idx(i,k);
            if (mhd.problem=="blast"){
                double rc = 0.2*std::min(g.Rmax, g.Zmax);
                double rr = std::sqrt(r*r + (z-0.5*g.Zmax)*(z-0.5*g.Zmax));
                F.rho[id] = 1.0;
                F.p[id]   = (rr<rc)? 1e-1 : 1e-2;
            } else {
                F.rho[id] = (z < 0.5*g.Zmax)? 1.0 : 0.125;
                F.p[id]   = (z < 0.5*g.Zmax)? 1.0 : 0.1;
            }
            F.vr[id]=F.vz[id]=F.vth[id]=0.0;
            F.Br[id]=0.0;
            F.Bz[id]=cfg.phys.Bz0;
        }
    }
}

static void ct_update(Fields& F, const RunConfig& cfg, double dt, double eta_ct){
    const auto& g = F.g;
    std::vector<double> E(g.size_r()*g.size_z(), 0.0);
    auto Eidx = [&](size_t i, size_t k){ return g.idx(i,k); };
    for (size_t i=1; i<g.size_r()-1; ++i){
        for (size_t k=1; k<g.size_z()-1; ++k){
            double vr = 0.25*(F.vr[g.idx(i,k)]+F.vr[g.idx(i-1,k)]+F.vr[g.idx(i,k-1)]+F.vr[g.idx(i-1,k-1)]);
            double vz = 0.25*(F.vz[g.idx(i,k)]+F.vz[g.idx(i-1,k)]+F.vz[g.idx(i,k-1)]+F.vz[g.idx(i-1,k-1)]);
            double Brc= 0.25*(F.Br[g.idx(i,k)]+F.Br[g.idx(i-1,k)]+F.Br[g.idx(i,k-1)]+F.Br[g.idx(i-1,k-1)]);
            double Bzc= 0.25*(F.Bz[g.idx(i,k)]+F.Bz[g.idx(i-1,k)]+F.Bz[g.idx(i,k-1)]+F.Bz[g.idx(i-1,k-1)]);
            double Etheta = -(vr*Bzc - vz*Brc);
            if (eta_ct>0.0){
                double dBr_dz = (F.Br[g.idx(i,k)] - F.Br[g.idx(i,k-1)]) / g.dz;
                double dBz_dr = (F.Bz[g.idx(i,k)] - F.Bz[g.idx(i-1,k)]) / g.dr;
                Etheta += - eta_ct * (dBr_dz - dBz_dr);
            }
            E[Eidx(i,k)] = Etheta;
        }
    }
    std::vector<double> Br_new(F.Br), Bz_new(F.Bz);
    for (size_t i=1; i<g.size_r()-1; ++i){
        for (size_t k=1; k<g.size_z()-1; ++k){
            double dE_dz = (E[Eidx(i,k+1)] - E[Eidx(i,k)]) / g.dz;
            double dE_dr = (E[Eidx(i+1,k)] - E[Eidx(i,k)]) / g.dr;
            Br_new[g.idx(i,k)] = F.Br[g.idx(i,k)] - dt * dE_dz;
            Bz_new[g.idx(i,k)] = F.Bz[g.idx(i,k)] + dt * dE_dr;
        }
    }
    F.Br.swap(Br_new); F.Bz.swap(Bz_new);
    for (size_t k=0;k<g.size_z();++k){
        F.Br[g.idx(g.Ng,k)] = F.Br[g.idx(g.Ng+1,k)];
        F.Br[g.idx(g.size_r()-g.Ng-1,k)] = F.Br[g.idx(g.size_r()-g.Ng-2,k)];
        F.Bz[g.idx(g.Ng,k)] = F.Bz[g.idx(g.Ng+1,k)];
        F.Bz[g.idx(g.size_r()-g.Ng-1,k)] = F.Bz[g.idx(g.size_r()-g.Ng-2,k)];
    }
    for (size_t i=0;i<g.size_r();++i){
        F.Br[g.idx(i,g.Ng)] = F.Br[g.idx(i,g.Ng+1)];
        F.Br[g.idx(i,g.size_z()-g.Ng-1)] = F.Br[g.idx(i,g.size_z()-g.Ng-2)];
        F.Bz[g.idx(i,g.Ng)] = F.Bz[g.idx(i,g.Ng+1)];
        F.Bz[g.idx(i,g.size_z()-g.Ng-1)] = F.Bz[g.idx(i,g.size_z()-g.Ng-2)];
    }
}

static void euler_sweep_r(Fields& F, const RunConfig& cfg, double gamma, recon::Limiter lim, double dt){
    const auto& g = F.g;
    const size_t i0=g.Ng, i1=g.Ng+g.Nr;
    const size_t k0=g.Ng, k1=g.Ng+g.Nz;
    std::vector<double> rho(g.size_r()), u(g.size_r()), p(g.size_r()), E(g.size_r());
    for (size_t k=k0; k<k1; ++k){
        for (size_t i=i0; i<i1; ++i){
            size_t id=g.idx(i,k);
            rho[i]=std::max(1e-12, F.rho[id]);
            u[i]=F.vr[id];
            p[i]=std::max(1e-12, F.p[id]);
            E[i]=p[i]/(gamma-1.0)+0.5*rho[i]*u[i]*u[i];
        }
        std::vector<double> drho,du,dp,dE;
        recon::slope_limited(rho,drho,i0,i1,lim);
        recon::slope_limited(u,du,i0,i1,lim);
        recon::slope_limited(p,dp,i0,i1,lim);
        recon::slope_limited(E,dE,i0,i1,lim);
        std::vector<double> rhoL,rhoR,uL,uR,pL,pR,EL,ER;
        recon::interfaces_lr(rho,drho,rhoL,rhoR,i0,i1);
        recon::interfaces_lr(u,du,uL,uR,i0,i1);
        recon::interfaces_lr(p,dp,pL,pR,i0,i1);
        recon::interfaces_lr(E,dE,EL,ER,i0,i1);
        std::vector<std::array<double,3>> Fhll(g.size_r());
        for (size_t i=i0; i+1<i1; ++i){
            rsolver::EulerState WL{rhoR[i], uR[i], pR[i], ER[i]};
            rsolver::EulerState WR{rhoL[i+1], uL[i+1], pL[i+1], EL[i+1]};
            std::array<double,3> UL,UR,FH;
            rsolver::prim_to_cons(gamma,WL,UL,0);
            rsolver::prim_to_cons(gamma,WR,UR,0);
            rsolver::hll_flux(gamma, UL, UR, FH);
            Fhll[i]=FH;
        }
        for (size_t i=i0; i<i1; ++i){
            size_t id=g.idx(i,k);
            std::array<double,3> cons{rho[i], rho[i]*u[i], E[i]};
            auto Fl = Fhll[i-1];
            auto Fr = Fhll[i];
            for (int n=0;n<3;++n){ cons[n] -= dt/g.dr * (Fr[n]-Fl[n]); }
            double rhoN=std::max(1e-12, cons[0]);
            double uN=cons[1]/rhoN;
            double EN=cons[2];
            double pN=std::max(1e-12,(gamma-1.0)*(EN-0.5*rhoN*uN*uN));
            F.rho[id]=rhoN; F.vr[id]=uN; F.p[id]=pN;
        }
    }
}

static void euler_sweep_z(Fields& F, const RunConfig& cfg, double gamma, recon::Limiter lim, double dt){
    const auto& g = F.g;
    const size_t i0=g.Ng, i1=g.Ng+g.Nr;
    const size_t k0=g.Ng, k1=g.Ng+g.Nz;
    std::vector<double> rho(g.size_z()), u(g.size_z()), p(g.size_z()), E(g.size_z());
    for (size_t i=i0; i<i1; ++i){
        for (size_t k=k0; k<k1; ++k){
            size_t id=g.idx(i,k);
            rho[k]=std::max(1e-12, F.rho[id]);
            u[k]=F.vz[id];
            p[k]=std::max(1e-12, F.p[id]);
            E[k]=p[k]/(gamma-1.0)+0.5*rho[k]*u[k]*u[k];
        }
        std::vector<double> drho,du,dp,dE;
        recon::slope_limited(rho,drho,k0,k1,lim);
        recon::slope_limited(u,du,k0,k1,lim);
        recon::slope_limited(p,dp,k0,k1,lim);
        recon::slope_limited(E,dE,k0,k1,lim);
        std::vector<double> rhoL,rhoR,uL,uR,pL,pR,EL,ER;
        recon::interfaces_lr(rho,drho,rhoL,rhoR,k0,k1);
        recon::interfaces_lr(u,du,uL,uR,k0,k1);
        recon::interfaces_lr(p,dp,pL,pR,k0,k1);
        recon::interfaces_lr(E,dE,EL,ER,k0,k1);
        std::vector<std::array<double,3>> Fhll(g.size_z());
        for (size_t k=k0; k+1<k1; ++k){
            rsolver::EulerState WL{rhoR[k], uR[k], pR[k], ER[k]};
            rsolver::EulerState WR{rhoL[k+1], uL[k+1], pL[k+1], EL[k+1]};
            std::array<double,3> UL,UR,FH;
            rsolver::prim_to_cons(gamma,WL,UL,0);
            rsolver::prim_to_cons(gamma,WR,UR,0);
            rsolver::hll_flux(gamma, UL, UR, FH);
            Fhll[k]=FH;
        }
        for (size_t k=k0; k<k1; ++k){
            size_t id=g.idx(i,k);
            std::array<double,3> cons{rho[k], rho[k]*u[k], E[k]};
            auto Fl = Fhll[k-1];
            auto Fr = Fhll[k];
            for (int n=0;n<3;++n){ cons[n] -= dt/g.dz * (Fr[n]-Fl[n]); }
            double rhoN=std::max(1e-12, cons[0]);
            double uN=cons[1]/rhoN;
            double EN=cons[2];
            double pN=std::max(1e-12,(gamma-1.0)*(EN-0.5*rhoN*uN*uN));
            F.rho[id]=rhoN; F.vz[id]=uN; F.p[id]=pN;
        }
    }
}

void run_2d_mhd_toy(Fields& F, const RunConfig& cfg, const MHD2DConfig& mhdcfg){
    const auto& g = F.g;
    namespace fs=std::filesystem; fs::create_directories(cfg.out_dir + "/debug");

    init_problem(F, cfg, mhdcfg);
    recon::Limiter lim = (mhdcfg.limiter=="minmod") ? recon::Limiter::Minmod : recon::Limiter::MC;

    // dt sencillo por sonido
    double vmax=1e-6;
    for (size_t i=g.Ng; i<g.Ng+g.Nr; ++i){
        for (size_t k=g.Ng; k<g.Ng+g.Nz; ++k){
            size_t id=g.idx(i,k);
            double cs = std::sqrt(std::max(0.0, mhdcfg.gamma * F.p[id] / std::max(1e-12, F.rho[id])));
            vmax = std::max(vmax, std::abs(F.vr[id])+cs);
            vmax = std::max(vmax, std::abs(F.vz[id])+cs);
        }
    }
    double dt = mhdcfg.cfl * std::min(g.dr, g.dz) / vmax;

    { std::ofstream(cfg.out_dir + "/debug/2d_mhd_metrics.csv") << "t,divB_L2,Etot\n"; }

    double t=0.0; int step=0;
    while (t < mhdcfg.t_end - 1e-16){
        euler_sweep_r(F, cfg, mhdcfg.gamma, lim, dt);
        euler_sweep_z(F, cfg, mhdcfg.gamma, lim, dt);
        ct_update(F, cfg, dt, mhdcfg.eta_ct);

        euler_sweep_r(F, cfg, mhdcfg.gamma, lim, 0.5*dt);
        euler_sweep_z(F, cfg, mhdcfg.gamma, lim, 0.5*dt);
        ct_update(F, cfg, 0.5*dt, mhdcfg.eta_ct);

        t += dt; step++;
        if (step % cfg.output_every == 0){
            io::write_snapshot(F, cfg, step, t);
            double divB = utils::divB_L2(F);
            double Etot=0.0;
            for (size_t i=0;i<g.size_r();++i){
                for (size_t k=0;k<g.size_z();++k){
                    size_t id=g.idx(i,k);
                    double ke = 0.5 * F.rho[id]*(F.vr[id]*F.vr[id]+F.vz[id]*F.vz[id]);
                    double ge = F.p[id]/(mhdcfg.gamma-1.0);
                    double me = 0.5*(F.Br[id]*F.Br[id]+F.Bz[id]*F.Bz[id]+F.Bth[id]*F.Bth[id]);
                    Etot += ke + ge + me;
                }
            }
            std::ofstream(cfg.out_dir + "/debug/2d_mhd_metrics.csv", std::ios::app)
                << std::setprecision(16) << t << "," << divB << "," << Etot << "\n";
        }
    }
}

} // namespace physics
