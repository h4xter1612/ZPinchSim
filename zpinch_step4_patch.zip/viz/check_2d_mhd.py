import os, sys, pandas as pd, numpy as np
m = "./data/debug/2d_mhd_metrics.csv"
if not os.path.exists(m):
    print("[FAIL] missing", m); sys.exit(2)
M = pd.read_csv(m)
if len(M) < 2:
    print("[WARN] not enough rows."); sys.exit(0)
divB = M["divB_L2"].values
Etot = M["Etot"].values
print(f"[2D_MHD_TOY] divB_L2 last: {divB[-1]:.3e}")
print(f"[2D_MHD_TOY] Etot first -> last: {Etot[0]:.6e} -> {Etot[-1]:.6e}")
ok = np.isfinite(divB[-1]) and np.isfinite(Etot[-1]) and (Etot[-1] < 10*np.max(Etot[:3]))
print("[OK] sanity passed." if ok else "[WARN] energy grew too much or NaNs.")
