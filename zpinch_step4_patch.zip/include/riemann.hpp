#pragma once
#include <array>
#include <algorithm>
#include <cmath>

namespace rsolver {

struct EulerState {
    double rho, u, p, E;
};
inline double cs(double gamma, const EulerState& W){
    return std::sqrt(std::max(0.0, gamma * W.p / std::max(1e-14, W.rho)));
}
inline void prim_to_cons(double gamma, const EulerState& W, std::array<double,3>& U, int){
    U[0] = W.rho;
    U[1] = W.rho * W.u;
    U[2] = W.E;
}
inline EulerState cons_to_prim(double gamma, const std::array<double,3>& U, int){
    EulerState W{};
    W.rho = std::max(1e-14, U[0]);
    W.u   = U[1] / W.rho;
    W.E   = U[2];
    double ke = 0.5 * W.rho * W.u * W.u;
    W.p   = std::max(1e-16, (gamma-1.0) * (W.E - ke));
    return W;
}
inline void flux_euler(double, const EulerState& W, std::array<double,3>& F){
    double u = W.u;
    double H = (W.E + W.p) / W.rho;
    F[0] = W.rho * u;
    F[1] = W.rho * u*u + W.p;
    F[2] = W.rho * H * u;
}
inline void hll_flux(double gamma,
                     const std::array<double,3>& UL, const std::array<double,3>& UR,
                     std::array<double,3>& FHLL){
    auto WL = cons_to_prim(gamma, UL, 0);
    auto WR = cons_to_prim(gamma, UR, 0);
    std::array<double,3> FL, FR;
    flux_euler(gamma, WL, FL);
    flux_euler(gamma, WR, FR);
    double SL = std::min(WL.u - cs(gamma,WL), WR.u - cs(gamma,WR));
    double SR = std::max(WL.u + cs(gamma,WL), WR.u + cs(gamma,WR));
    if (SL >= 0){ FHLL = FL; return; }
    if (SR <= 0){ FHLL = FR; return; }
    for (int n=0;n<3;++n){
        FHLL[n] = (SR*FL[n] - SL*FR[n] + SL*SR*(UR[n]-UL[n])) / (SR - SL + 1e-16);
    }
}

} // namespace rsolver
