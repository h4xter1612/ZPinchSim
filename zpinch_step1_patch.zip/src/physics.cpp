
#include "physics.hpp"
#include "io.hpp"
#include <cmath>
#include <random>
#include <fstream>
#include <filesystem>
#include <iomanip>

namespace physics {

// ------------------------- 0D LR circuit -------------------------
static inline double driveV(const Circuit& c, double t){
    if (c.shape=="pulse"){
        return (t <= c.t_pulse) ? c.V0 : 0.0;
    }
    // default: step
    return c.V0;
}

void solve_LR(const Circuit& c, double t_end, double dt, const std::string& out_dir){
    namespace fs = std::filesystem;
    fs::create_directories(out_dir + "/debug");
    std::ofstream f(out_dir + "/debug/0d_circuit.csv");
    f << "t,I,V,dI_dt\n";

    double I = 0.0;
    for (double t=0.0; t<=t_end + 1e-16; t += dt){
        double V = driveV(c,t);
        // RK2 Heun for dI/dt = (V - R I)/L
        double k1 = (V - c.R*I)/c.L;
        double Ipred = I + dt*k1;
        double V2 = driveV(c, t+dt);
        double k2 = (V2 - c.R*Ipred)/c.L;
        double dI = 0.5*dt*(k1+k2);
        I += dI;
        f << std::setprecision(16) << t << "," << I << "," << V << "," << (dI/dt) << "\n";
    }
}

// ----------------------- radial equilibrium ----------------------
static void build_Btheta_profile(const Fields& F, const RunConfig& cfg, const Equilibrium& eq, std::vector<double>& Bth_prof){
    const auto& g = F.g;
    const size_t Nr = g.size_r();
    Bth_prof.assign(Nr, 0.0);

    auto Jz = [&](double r)->double {
        double R0 = g.Rmax;
        if (eq.type=="bennett"){
            double a = eq.a * R0;
            double x = r/a;
            return 1.0/std::pow(1.0 + x*x, 2.0);
        } else { // tophat
            double r0 = eq.r0 * R0;
            return (r <= r0) ? 1.0 : 0.0;
        }
    };

    const double dr = g.dr;
    std::vector<double> J(Nr, 0.0);
    double Itot_raw = 0.0;
    for (size_t i=0; i<Nr; ++i){
        double r = (int(i)-int(g.Ng)+0.5)*dr;
        if (r <= 0.0) { J[i] = 0.0; continue; }
        J[i] = Jz(r);
        Itot_raw += J[i] * r * dr;
    }
    double scale = (Itot_raw>0.0) ? (eq.I0 / Itot_raw) : 0.0;
    for (size_t i=0;i<Nr;++i) J[i] *= scale;

    double Ienc = 0.0;
    for (size_t i=0; i<Nr; ++i){
        double r = (int(i)-int(g.Ng)+0.5)*dr;
        if (r <= 0.0){ Bth_prof[i] = 0.0; continue; }
        Ienc += J[i] * r * dr;
        Bth_prof[i] = Ienc / r;
    }
}

void build_equilibrium(Fields& F, const RunConfig& cfg, const Equilibrium& eq){
    const auto& g = F.g;
    const size_t Nr = g.size_r();
    const size_t Nz = g.size_z();
    namespace fs = std::filesystem;
    fs::create_directories(cfg.out_dir + "/debug");

    std::vector<double> Bth_prof;
    build_Btheta_profile(F, cfg, eq, Bth_prof);

    for (size_t i=0;i<Nr;++i){
        for (size_t k=0;k<Nz;++k){
            size_t id = g.idx(i,k);
            F.rho[id] = eq.rho0;
            F.Bz[id]  = cfg.phys.Bz0;
            F.Br[id]  = 0.0;
            F.vr[id] = F.vz[id] = F.vth[id] = 0.0;
            F.p[id] = eq.p0;
            F.Bth[id] = Bth_prof[i];
        }
    }

    std::ofstream fres(cfg.out_dir + "/debug/equilibrium_residual.csv");
    fres << "r,residual,ptot\n";
    std::ofstream fprof(cfg.out_dir + "/debug/equilibrium_profiles.csv");
    fprof << "r,p,Btheta,Bz\n";

    for (size_t i=1; i<Nr-1; ++i){
        double r = (int(i)-int(g.Ng)+0.5)*g.dr;
        double r_p = (int(i+1)-int(g.Ng)+0.5)*g.dr;
        double r_m = (int(i-1)-int(g.Ng)+0.5)*g.dr;
        size_t id = g.idx(i, g.Ng);
        size_t idp= g.idx(i+1, g.Ng);
        size_t idm= g.idx(i-1, g.Ng);
        double Bth = F.Bth[id], Bthp=F.Bth[idp], Bthm=F.Bth[idm];
        double Bz  = F.Bz[id];
        double p   = F.p[id],  pp  =F.p[idp],   pm  =F.p[idm];

        double pt = p + 0.5*(Bth*Bth + Bz*Bz);
        double ptp= pp+ 0.5*(Bthp*Bthp + Bz*Bz);
        double ptm= pm+ 0.5*(Bthm*Bthm + Bz*Bz);
        double dpt_dr = (ptp - ptm)/(r_p - r_m);
        double residual = dpt_dr + (r>1e-14 ? (Bth*Bth)/r : 0.0);

        fres << std::setprecision(16) << r << "," << residual << "," << pt << "\n";
        fprof << std::setprecision(16) << r << "," << p << "," << Bth << "," << Bz << "\n";
    }
}

// ----------------------- legacy initialize -----------------------
void initialize(Fields& F, const RunConfig& cfg) {
    const auto& g = F.g;
    double r0 = 0.25 * g.Rmax;
    for (size_t i=0;i<g.size_r();++i){
        double r = (int(i)-int(g.Ng)+0.5)*g.dr;
        for (size_t k=0;k<g.size_z();++k){
            size_t id = g.idx(i,k);
            F.rho[id] = (r<r0) ? 1.0 : 0.2;
            F.p[id]   = (r<r0) ? 1e-2 : 5e-3;
            F.Bz[id]  = cfg.phys.Bz0;
            F.Bth[id] = (r<r0) ? r/r0 : (r>1e-12 ? r0/r : 0.0);
        }
    }
}

void apply_sources(Fields& F, const RunConfig& cfg, double /*dt*/) {
    (void)F; (void)cfg;
}

double max_wavespeed(const Fields& F, const RunConfig& /*cfg*/) {
    (void)F;
    return 1.0;
}

} // namespace physics
