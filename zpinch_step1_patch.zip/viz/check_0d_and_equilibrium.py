
import numpy as np, pandas as pd, matplotlib.pyplot as plt, os, sys, glob, json

def fit_LR_step(L, R, V0, t):
    tau = L/R
    return (V0/R) * (1.0 - np.exp(-t/tau))

def main():
    base = "./data/debug"
    circ = os.path.join(base, "0d_circuit.csv")
    eq_r = os.path.join(base, "equilibrium_residual.csv")
    eq_p = os.path.join(base, "equilibrium_profiles.csv")

    ok = True
    if not os.path.exists(circ):
        print("[FAIL] missing", circ); ok=False
    if not os.path.exists(eq_r):
        print("[FAIL] missing", eq_r); ok=False
    if not os.path.exists(eq_p):
        print("[FAIL] missing", eq_p); ok=False
    if not ok: sys.exit(2)

    # ---- Check LR fit ----
    C = pd.read_csv(circ)
    # For now, assume defaults L=1, R=0.1, V0=1
    L,R,V0 = 1.0, 0.1, 1.0
    t = C["t"].values
    I = C["I"].values
    Ithe = fit_LR_step(L,R,V0,t)
    rms = np.sqrt(np.mean((I - Ithe)**2))
    print(f"[LR] RMS error vs step-response (L={L},R={R},V0={V0}): {rms:.3e}")

    # ---- Check equilibrium residual ----
    Rcsv = pd.read_csv(eq_r)
    res_L2 = np.sqrt(np.mean(Rcsv["residual"].values**2))
    print(f"[EQ] radial force-balance residual L2: {res_L2:.3e}")

    if rms < 5e-3 and res_L2 < 1e-2:
        print("[OK] Step 1 checks passed.")
        sys.exit(0)
    else:
        print("[WARN] Thresholds not met (tune parameters / resolution).")
        sys.exit(0)

if __name__ == "__main__":
    main()
