
#pragma once
#include "state.hpp"
#include <string>

namespace physics {

// ---- Step 1: 0D LR circuit ----
struct Circuit {
    double L{1.0};     // inductance
    double R{1.0};     // resistance
    double V0{1.0};    // drive amplitude
    std::string shape{"step"}; // "step" or "pulse"
    double t_pulse{0.0};       // pulse duration if shape=="pulse"
};
// Integrate LR and write data/debug/0d_circuit.csv
void solve_LR(const Circuit& c, double t_end, double dt, const std::string& out_dir);

// ---- Step 1: radial equilibrium ----
struct Equilibrium {
    std::string type{"tophat"}; // "tophat" or "bennett"
    double I0{1.0};  // total current (non-dim or SI per your scaling)
    double r0{0.25}; // characteristic radius (fraction of Rmax for tophat)
    double a{0.2};   // Bennett scale radius (fraction of Rmax)
    double p0{1e-2}; // central gas pressure
    double rho0{1.0};
};

// Build (ρ, p, Bθ, Bz) equilibrium on Fields and write diagnostics:
// data/debug/equilibrium_residual.csv  (r, residual)
// data/debug/equilibrium_profiles.csv  (r, p, Btheta, Bz)
void build_equilibrium(Fields& F, const RunConfig& cfg, const Equilibrium& eq);

// Initialize (legacy), kept for compatibility
void initialize(Fields& F, const RunConfig& cfg);

// Apply cylindrical source terms near r=0 and wall BCs
void apply_sources(Fields& F, const RunConfig& cfg, double dt);

// Compute max wavespeed (very rough placeholder)
double max_wavespeed(const Fields& F, const RunConfig& cfg);

} // namespace physics
