
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import re
from pathlib import Path
import numpy as np
import pandas as pd
from dataclasses import dataclass
from typing import List, Tuple, Optional, Dict

@dataclass
class GridMeta:
    Nr: int = 128
    Nz: int = 256
    Ng: int = 0
    Rmax: float = 0.02
    Zmax: float = 0.10

def _read_meta(path: Path) -> Dict[str, str]:
    d = {}
    with open(path, "r", encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            if "#" in ln:
                ln = ln.split("#", 1)[0].strip()
            for part in [p.strip() for p in ln.replace(":", "=").split(",")]:
                if "=" in part:
                    k, v = part.split("=", 1)
                    d[k.strip()] = v.strip()
    return d

def discover_grid_meta(data_root: Path) -> GridMeta:
    metas = sorted((data_root).glob("fields_*_meta.txt"))
    if not metas:
        return GridMeta()
    meta = _read_meta(metas[-1])
    Nr   = int(meta.get("Nr", "128"))
    Nz   = int(meta.get("Nz", "256"))
    Ng   = int(meta.get("Ng", "0"))
    Rmax = float(meta.get("Rmax", "0.02"))
    Zmax = float(meta.get("Zmax", "0.10"))
    return GridMeta(Nr=Nr, Nz=Nz, Ng=Ng, Rmax=Rmax, Zmax=Zmax)

def _step_from_name(p: Path) -> Optional[int]:
    m = re.search(r"fields_(\d+)_", p.name)
    return int(m.group(1)) if m else None

def _load_times_from_diag(data_root: Path) -> Dict[int, float]:
    out: Dict[int, float] = {}
    diag = data_root / "diag.csv"
    if diag.exists():
        try:
            df = pd.read_csv(diag)
            if "step" in df.columns and "t" in df.columns:
                for _, row in df.iterrows():
                    try:
                        out[int(row["step"])] = float(row["t"])
                    except:
                        pass
        except:
            pass
    return out

def _load_field_series(data_root: Path, meta: GridMeta, field_name: str) -> Tuple[List[np.ndarray], List[Path]]:
    files = sorted((data_root).glob(f"fields_*_{field_name}.csv"))
    arrs, used = [], []
    if not files:
        return arrs, used
    Nr, Nz, Ng = meta.Nr, meta.Nz, meta.Ng
    interior = Nr * Nz
    full = (Nr + 2*Ng) * (Nz + 2*Ng)
    for p in files:
        try:
            a = np.loadtxt(p, delimiter=",")
        except Exception:
            continue
        n = a.size
        if n == interior:
            arrs.append(a.reshape(Nr, Nz)); used.append(p)
        elif n == full:
            A = a.reshape(Nr + 2*Ng, Nz + 2*Ng)[Ng:Ng+Nr, Ng:Ng+Nz]
            arrs.append(A); used.append(p)
        else:
            continue
    return arrs, used

def _pick_ring_index(r_over_R: float, Nr: int) -> int:
    return int(np.clip(round(r_over_R * Nr), 0, Nr-1))

def _fft_amplitude(slice_z: np.ndarray, k_target: float, Lz: float, continuous_k: bool=False):
    Nz_local = slice_z.shape[0]
    dz = Lz / Nz_local
    k_axis = 2.0 * np.pi * np.fft.rfftfreq(Nz_local, d=dz)
    F = np.fft.rfft(slice_z)
    j0 = int(np.argmin(np.abs(k_axis - k_target)))
    if (not continuous_k) or j0==0 or j0==len(k_axis)-1:
        return float(np.abs(F[j0])), float(k_axis[j0])
    mags = np.abs(F)
    jm1, jp1 = j0-1, j0+1
    y1, y2, y3 = mags[jm1], mags[j0], mags[jp1]
    denom = (y1 - 2*y2 + y3)
    if denom == 0:
        return float(y2), float(k_axis[j0])
    delta = 0.5 * (y1 - y3) / denom
    j_star = j0 + delta
    k_star = float(np.interp(j_star, np.arange(len(k_axis)), k_axis))
    amp_star = float(y2 - 0.25*(y1 - y3)*delta)
    return abs(amp_star), k_star

@dataclass
class ModeResult:
    case: str
    field: str
    r_over_R: float
    snaps: int
    k_target: float
    k_used: float
    mode: str
    gamma_1_s: float
    last_amp: float
    series: pd.DataFrame

def analyze_case(data_root: Path,
                 field: str = "vr",
                 k_target: float = 40.0,
                 r_over_R: float = 0.3,
                 zmax_override: Optional[float] = None,
                 label: Optional[str] = None,
                 continuous_k: bool = False) -> ModeResult:
    data_root = Path(data_root)
    meta = discover_grid_meta(data_root)
    Zmax = meta.Zmax if zmax_override is None else float(zmax_override)

    series, files_used = _load_field_series(data_root, meta, field)
    if not series:
        for alt in ("vr", "Bth", "p", "rho"):
            if alt == field: 
                continue
            series, files_used = _load_field_series(data_root, meta, alt)
            if series:
                field = alt
                break
    if not series:
        raise RuntimeError(f"Sin snapshots válidos en {data_root} para {field} (ni alternativos).")

    times_by_step = _load_times_from_diag(data_root)
    ts = []
    for p in files_used:
        stp = _step_from_name(p)
        if stp is not None and stp in times_by_step:
            ts.append(times_by_step[stp])
        else:
            ts.append(np.nan)
    if np.any(~np.isfinite(ts)):
        ts = list(np.arange(len(series), dtype=float))

    ridx = _pick_ring_index(r_over_R, meta.Nr)

    amps = []
    k_used = None
    for A, tt in zip(series, ts):
        if ridx < 0 or ridx >= A.shape[0]:
            continue
        slice_z = A[ridx, :]
        amp, k_eff = _fft_amplitude(slice_z, k_target, Zmax, continuous_k=continuous_k)
        k_used = k_eff
        amps.append((tt, amp))

    if not amps:
        raise RuntimeError("No se pudieron medir amplitudes (¿ridx fuera de rango?).")

    arr = np.array([(tt, aa) for tt, aa in amps if np.isfinite(tt) and np.isfinite(aa)])
    arr = arr[arr[:, 0].argsort()]
    tt = arr[:, 0]
    AA = arr[:, 1]
    mask = AA > 0
    tt = tt[mask]; AA = AA[mask]

    if len(tt) < 5:
        gamma = np.nan
    else:
        m = max(5, len(tt)//2)
        x = tt[-m:]; y = np.log(AA[-m:])
        coef = np.polyfit(x, y, 1)
        gamma = float(coef[0])

    mode = "continuous" if continuous_k else "binned"
    label = label or data_root.name
    df_series = pd.DataFrame({"t": tt, "A": AA})
    return ModeResult(case=label, field=field, r_over_R=float(r_over_R),
                      snaps=len(tt), k_target=float(k_target), k_used=float(k_used),
                      mode=mode, gamma_1_s=gamma, last_amp=float(AA[-1]),
                      series=df_series)
