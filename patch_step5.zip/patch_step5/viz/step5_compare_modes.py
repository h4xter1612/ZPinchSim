
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
import numpy as np
from _modes_core import analyze_case

def parse_args():
    ap = argparse.ArgumentParser(description="Step 5 — comparar casos y reportar γ")
    ap.add_argument("--roots", nargs="+", required=True, help="Rutas a directorios con datos")
    ap.add_argument("--labels", nargs="+", help="Etiquetas para los casos (mismo largo que --roots)")
    ap.add_argument("--field", default="vr", choices=["vr","Bth","p","rho"])
    ap.add_argument("--k-target", type=float, default=40.0)
    ap.add_argument("--r-over-R", type=float, default=0.3)
    ap.add_argument("--zmax", type=float, default=None)
    ap.add_argument("--outdir", default="out/step5")
    ap.add_argument("--continuous-k", action="store_true")
    ap.add_argument("--log-amp", action="store_true")
    return ap.parse_args()

def ensure_outdir(p: Path):
    p.mkdir(parents=True, exist_ok=True)

def main():
    args = parse_args()
    roots = [Path(r) for r in args.roots]
    labels = args.labels if args.labels else [r.name for r in roots]
    if len(labels) != len(roots):
        raise SystemExit("labels y roots deben tener la misma longitud")

    outdir = Path(args.outdir)
    ensure_outdir(outdir)

    results = []
    for root, lab in zip(roots, labels):
        res = analyze_case(root, field=args.field, k_target=args.k_target,
                           r_over_R=args.r_over_R, zmax_override=args.zmax,
                           label=lab, continuous_k=args.continuous_k)
        results.append(res)
        res.series.to_csv(outdir / f"amplitude_{lab}.csv", index=False)

    df = pd.DataFrame([{
        "case": r.case, "field": r.field, "r_over_R": r.r_over_R, "snaps": r.snaps,
        "k_target": r.k_target, "k_used": r.k_used, "mode": r.mode,
        "gamma_1_s": r.gamma_1_s, "last_amp": r.last_amp,
    } for r in results])
    df.to_csv(outdir / "summary.csv", index=False)

    try:
        import matplotlib.pyplot as plt
        plt.figure()
        for r in results:
            if args.log_amp:
                plt.plot(r.series["t"].values, np.log10(r.series["A"].values + 1e-300), label=r.case)
                plt.ylabel("log10 Amplitud")
            else:
                plt.plot(r.series["t"].values, r.series["A"].values, label=r.case)
                plt.ylabel("Amplitud")
        plt.xlabel("t"); plt.title("Amplitud del modo vs tiempo"); plt.legend(); plt.tight_layout()
        plt.savefig(outdir / "plot_amplitude.png", dpi=150)

        plt.figure()
        idx = np.arange(len(results))
        gammas = [r.gamma_1_s for r in results]
        plt.bar(idx, gammas)
        plt.xticks(idx, [r.case for r in results], rotation=20)
        plt.ylabel("γ (1/s)"); plt.title("Comparación de tasa de crecimiento"); plt.tight_layout()
        plt.savefig(outdir / "plot_comparison.png", dpi=150)
    except Exception:
        pass

    print(f"[STEP5] Resumen: {outdir/'summary.csv'}")
    print(f"[STEP5] Series:  {outdir/'amplitude_<case>.csv'}")
    print(f"[STEP5] Plots (si matplotlib): {outdir/'plot_amplitude.png'}, {outdir/'plot_comparison.png'}")

if __name__ == "__main__":
    main()
