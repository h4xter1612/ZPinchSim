
# Paso 5 — Paquete de comparación y reporte

Este parche añade utilidades para **comparar casos (p. ej. Bz_low vs Bz_high)** y producir un **resumen + gráfica** de amplitud y la **tasa de crecimiento (γ)**, reutilizando la lógica que ya te funcionó.

## Contenido
- `viz/_modes_core.py` — Núcleo reutilizable para cargar snapshots, medir amplitud del modo k y hacer el fit exponencial (γ). Es una adaptación compacta del `check_modes.py` que ya validaste, con **salida silenciosa** y API clara.
- `viz/step5_compare_modes.py` — Script “driver” para evaluar **varios casos** y generar:
  - `out/step5/summary.csv` con columnas: `case, field, r_over_R, snaps, k_target, k_used, mode, gamma_1_s, last_amp`.
  - `out/step5/amplitude_<case>.csv` con la serie `(t, A)` por caso.
  - `out/step5/plot_amplitude.png` (amplitudes vs tiempo, escala log opcional).
  - `out/step5/plot_comparison.png` (γ por caso).
- `viz/requirements_step5.txt` — Dependencias mínimas.
- `.gitignore` — Ignora `out/` generado por los scripts.

## Uso rápido

```
# Comparar dos directorios de datos ya generados
python viz/step5_compare_modes.py --roots data_BzLow data_BzHigh   --labels BzLow BzHigh   --field vr --k-target 40 --r-over-R 0.30 --zmax 0.10   --outdir out/step5 --continuous-k --log-amp
```
