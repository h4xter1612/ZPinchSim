
import numpy as np
import pandas as pd
import glob, os, sys
from pathlib import Path

BASE = Path(".")
DATA = BASE / "data"
META = sorted(DATA.glob("fields_*_meta.txt"))
if not META:
    print("[FAIL] no snapshots")
    sys.exit(1)

# Read grid meta from last meta file (Nr,Nz,Rmax,Zmax)
def read_meta(path):
    d = {}
    with open(path, "r") as f:
        for ln in f:
            ln = ln.strip()
            if not ln or ":" not in ln: 
                continue
            k,v = ln.split(":",1)
            d[k.strip()] = v.strip()
    return d

last_meta = read_meta(META[-1])
Nr = int(last_meta.get("Nr","128"))
Nz = int(last_meta.get("Nz","256"))
Rmax = float(last_meta.get("Rmax","0.02"))
Zmax = float(last_meta.get("Zmax","0.10"))

# Load all rho/vr/Bth snapshots
def load_snap(prefix):
    P = sorted(DATA.glob(f"{prefix}_*_*.csv"))
    out = []
    for p in P:
        arr = np.loadtxt(p, delimiter=",")
        out.append(arr.reshape(Nr, Nz))
    return out

rho_snaps = load_snap("fields")
# Spiral through to identify vr, Bth by filenames:
vr_files = sorted(DATA.glob("fields_*_vr.csv"))
bth_files = sorted(DATA.glob("fields_*_Bth.csv"))
p_files = sorted(DATA.glob("fields_*_p.csv"))

def load_list(paths):
    out = []
    for p in paths:
        arr = np.loadtxt(p, delimiter=",")
        out.append(arr.reshape(Nr, Nz))
    return out

vr_snaps = load_list(vr_files) if vr_files else []
bth_snaps = load_list(bth_files) if bth_files else []
p_snaps = load_list(p_files) if p_files else []

# Time stamps from diag.csv if present
t = []
diag = DATA / "diag.csv"
if diag.exists():
    df = pd.read_csv(diag)
    if "t" in df.columns:
        t = df["t"].values
else:
    # fallback: infer from meta order (approx)
    t = np.arange(len(vr_snaps), dtype=float)

def pick_ring_index(r_over_R):
    # choose i closest to r = r_over_R * Rmax
    dr = Rmax / Nr
    ridx = int(np.clip(round(r_over_R * Rmax / dr), 0, Nr-1))
    return ridx

# read monitor config if present
r_over_R = 0.3
field = "vr"
yaml_guess = BASE / "configs" / "run2d_modes.yaml"
if yaml_guess.exists():
    with open(yaml_guess, "r") as f:
        for ln in f:
            if ln.strip().startswith("r_over_R"):
                r_over_R = float(ln.split(":")[1].strip())
            if ln.strip().startswith("field"):
                field = ln.split(":")[1].strip()

ridx = pick_ring_index(r_over_R)

def amplitude_k(slice_z, k_target, Lz):
    # FFT in z and pick bin nearest to k_target
    Nz = slice_z.shape[0]
    dz = Lz / Nz
    ks = 2*np.pi*np.fft.rfftfreq(Nz, d=dz)  # angular wavenumber
    F = np.fft.rfft(slice_z)
    j = np.argmin(np.abs(ks - k_target))
    return np.abs(F[j]), ks[j]

series = []
for n in range(len(vr_snaps)):
    if field == "vr" and vr_snaps:
        slice_z = vr_snaps[n][ridx, :]
    elif field == "Bth" and bth_snaps:
        slice_z = bth_snaps[n][ridx, :]
    else:
        continue
    amp, k_eff = amplitude_k(slice_z, k_target=40.0, Lz=Zmax)
    tt = t[n] if n < len(t) else n
    series.append((tt, amp))

if len(series) < 3:
    print("[WARN] not enough snapshots to estimate growth.")
    sys.exit(0)

series = np.array(series)
tt = series[:,0]
AA = series[:,1]
# simple log-slope over last half
m = max(3, len(tt)//2)
x = tt[-m:]
y = np.log(np.maximum(AA[-m:], 1e-30))
coef = np.polyfit(x, y, 1)
gamma = coef[0]

print(f"[MODES] samples={len(tt)}  growth_rate ~ {gamma:.3e}  (1/s)")
print(f"[MODES] last amplitude = {AA[-1]:.3e}")
