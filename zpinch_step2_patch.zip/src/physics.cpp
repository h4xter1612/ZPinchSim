#include "physics.hpp"
#include "io.hpp"
#include "utils.hpp"
#include <cmath>
#include <random>
#include <fstream>
#include <filesystem>
#include <iomanip>
#include <algorithm>

namespace physics {
// --- Step 1 pieces (abbrev) ---
static inline double driveV(const Circuit& c, double t){ if (c.shape=="pulse"){ return (t<=c.t_pulse)?c.V0:0.0; } return c.V0; }
void solve_LR(const Circuit& c, double t_end, double dt, const std::string& out_dir){
    namespace fs = std::filesystem; fs::create_directories(out_dir + "/debug");
    std::ofstream f(out_dir + "/debug/0d_circuit.csv"); f << "t,I,V,dI_dt\n";
    double I=0.0; for(double t=0.0; t<=t_end+1e-16; t+=dt){ double V=driveV(c,t);
        double k1=(V-c.R*I)/c.L; double Ipred=I+dt*k1; double V2=driveV(c,t+dt);
        double k2=(V2-c.R*Ipred)/c.L; double dI=0.5*dt*(k1+k2); I+=dI;
        f<<std::setprecision(16)<<t<<","<<I<<","<<V<<","<<(dI/dt)<<"\n"; }
}

static void build_Btheta_profile(const Fields& F, const RunConfig& cfg, const Equilibrium& eq, std::vector<double>& Bth_prof){
    const auto& g=F.g; const size_t Nr_phys=g.Nr; const size_t Nr_total=g.size_r(); const size_t Ng=g.Ng;
    Bth_prof.assign(Nr_total,0.0);
    auto Jz_shape = [&](double r)->double{
        const double R0=g.Rmax;
        if(eq.type=="bennett"){ const double a=std::max(1e-12, eq.a*R0); const double x=r/a; return 1.0/std::pow(1.0+x*x,2.0); }
        const double r0=eq.r0*R0; const double w=0.05*R0; return 0.5*(1.0-std::tanh((r-r0)/w));
    };
    const double dr=g.dr; std::vector<double> J(Nr_phys,0.0); double Itot_raw=0.0;
    for(size_t ip=0; ip<Nr_phys; ++ip){ size_t i=Ng+ip; double r=(int(i)-int(Ng)+0.5)*dr; if(r<=0.0){J[ip]=0.0;continue;} J[ip]=Jz_shape(r); Itot_raw+=J[ip]*r*dr; }
    double scale=(Itot_raw>0.0)?(eq.I0/Itot_raw):0.0; for(double& v:J) v*=scale;
    double Ienc=0.0; for(size_t ip=0; ip<Nr_phys; ++ip){ size_t i=Ng+ip; double r=(int(i)-int(Ng)+0.5)*dr; if(r<=0.0){Bth_prof[i]=0.0;continue;} Ienc+=J[ip]*r*dr; Bth_prof[i]=Ienc/r; }
    for(size_t i=0;i<Ng;++i) Bth_prof[i]=Bth_prof[Ng];
    for(size_t i=Ng+Nr_phys;i<Nr_total;++i) Bth_prof[i]=Bth_prof[Ng+Nr_phys-1];
}

void build_equilibrium(Fields& F, const RunConfig& cfg, const Equilibrium& eq){
    const auto& g=F.g; const size_t Nr_phys=g.Nr; const size_t Ng=g.Ng;
    namespace fs=std::filesystem; fs::create_directories(cfg.out_dir + "/debug");
    std::vector<double> Bth; build_Btheta_profile(F,cfg,eq,Bth);
    std::vector<double> rhs(g.size_r(),0.0), p(g.size_r(),0.0); p[Ng]=eq.p0;
    for(size_t ip=Ng; ip<Ng+Nr_phys; ++ip){
        double r=(int(ip)-int(Ng)+0.5)*g.dr; double dB=0.0;
        if(ip==Ng) dB=(Bth[ip+1]-Bth[ip])/g.dr;
        else if(ip==Ng+Nr_phys-1) dB=(Bth[ip]-Bth[ip-1])/g.dr;
        else dB=(Bth[ip+1]-Bth[ip-1])/(2.0*g.dr);
        double r_safe=(r>1e-14? r:1e-14);
        rhs[ip]=-( Bth[ip]*dB + (Bth[ip]*Bth[ip])/r_safe );
        if(ip>Ng) p[ip]=p[ip-1]+0.5*(rhs[ip-1]+rhs[ip])*g.dr;
    }
    for(size_t i=0;i<Ng;++i) p[i]=p[Ng];
    for(size_t i=Ng+Nr_phys;i<g.size_r();++i) p[i]=p[Ng+Nr_phys-1];
    for(size_t i=0;i<g.size_r();++i){
        for(size_t k=0;k<g.size_z();++k){
            size_t id=g.idx(i,k);
            F.rho[id]=eq.rho0; F.Br[id]=0.0; F.vr[id]=F.vz[id]=F.vth[id]=0.0;
            F.Bz[id]=cfg.phys.Bz0; F.Bth[id]=Bth[i]; F.p[id]=p[i];
        }
    }
    std::ofstream fres(cfg.out_dir + "/debug/equilibrium_residual.csv"); fres<<"r,residual,ptot\n";
    std::ofstream fprof(cfg.out_dir + "/debug/equilibrium_profiles.csv"); fprof<<"r,p,Btheta,Bz\n";
    for(size_t ip=Ng+1; ip<Ng+Nr_phys-1; ++ip){
        double r=(int(ip)-int(Ng)+0.5)*g.dr; double rp1=(int(ip+1)-int(Ng)+0.5)*g.dr; double rm1=(int(ip-1)-int(Ng)+0.5)*g.dr;
        size_t id=g.idx(ip,Ng), idp=g.idx(ip+1,Ng), idm=g.idx(ip-1,Ng);
        double Bth0=F.Bth[id], Bthp=F.Bth[idp], Bthm=F.Bth[idm], Bz=F.Bz[id];
        double p0=F.p[id], pp=F.p[idp], pm=F.p[idm];
        double pt=p0+0.5*(Bth0*Bth0+Bz*Bz), ptp=pp+0.5*(Bthp*Bthp+Bz*Bz), ptm=pm+0.5*(Bthm*Bthm+Bz*Bz);
        double dpt=(ptp-ptm)/(rp1-rm1);
        double res=dpt + (r>1e-14? (Bth0*Bth0)/r : 0.0);
        fres<<std::setprecision(16)<<r<<","<<res<<","<<pt<<"\n";
        fprof<<std::setprecision(16)<<r<<","<<p0<<","<<Bth0<<","<<Bz<<"\n";
    }
}

static inline double eta_profile(double r, const Grid& g, const Resistivity& rp){
    double eta=rp.eta0; double rwall=rp.r_wall_frac*g.Rmax;
    if(r>rwall){ double s=std::min(1.0, (r-rwall)/std::max(1e-12, g.Rmax-rwall)); eta*= (1.0 + s*(rp.eta_wall_mult-1.0)); }
    return eta;
}
static void apply_bc_radial(Fields& F, const RunConfig& cfg, const RadialBC& bc){
    const auto& g=F.g; const size_t Ng=g.Ng; const size_t Nr_total=g.size_r(); const size_t i_wall=Ng+g.Nr-1;
    for(size_t k=0;k<g.size_z();++k){
        for(size_t gi=0; gi<Ng; ++gi){
            size_t i_ghost=Ng-1-gi, i_src=Ng+gi; size_t idg=g.idx(i_ghost,k), ids=g.idx(i_src,k);
            F.rho[idg]=F.rho[ids]; F.p[idg]=F.p[ids]; F.Bz[idg]=F.Bz[ids]; F.Bth[idg]=F.Bth[ids];
            F.Br[idg]=-F.Br[ids]; F.vr[idg]=-F.vr[ids]; F.vz[idg]=F.vz[ids]; F.vth[idg]=F.vth[ids];
        }
    }
    for(size_t k=0;k<g.size_z();++k){
        for(size_t gi=0; gi<Ng; ++gi){
            size_t i_ghost=i_wall+1+gi; if(i_ghost>=Nr_total) break;
            size_t idg=g.idx(i_ghost,k), ids=g.idx(i_wall,k);
            F.Bth[idg]=F.Bth[ids]; F.Br[idg]=0.0; F.rho[idg]=F.rho[ids]; F.p[idg]=F.p[ids];
            if(bc.clamp_Bz_at_wall) F.Bz[idg]=F.Bz[ids];
            F.vr[idg]=0.0; F.vz[idg]=F.vz[ids]; F.vth[idg]=F.vth[ids];
        }
    }
}

void step_1d_r(Fields& F, const RunConfig& cfg, double& t, double dt, const RadialBC& bc, const Resistivity& rp, bool write_metrics){
    const auto& g=F.g; const size_t Ng=g.Ng; const size_t Nr_phys=g.Nr; const size_t Nz_phys=g.Nz;
    auto lapl_r = [&](size_t i)->double{
        const double r=(int(i)-int(Ng)+0.5)*g.dr; const double rp1=(int(i+1)-int(Ng)+0.5)*g.dr; const double rm1=(int(i-1)-int(Ng)+0.5)*g.dr;
        const double dBp=(F.Bth[g.idx(i+1,Ng)]-F.Bth[g.idx(i,Ng)])/g.dr; const double dBm=(F.Bth[g.idx(i,Ng)]-F.Bth[g.idx(i-1,Ng)])/g.dr;
        const double r_safe=(r>1e-14? r:1e-14); return ((rp1*dBp)-(rm1*dBm))/(r_safe*g.dr);
    };
    std::vector<double> BthA(F.Bth);
    for(size_t ip=Ng+1; ip<Ng+Nr_phys-1; ++ip){
        double r=(int(ip)-int(Ng)+0.5)*g.dr; double eta=eta_profile(r,g,rp);
        size_t id=g.idx(ip,Ng); double ddt=eta*lapl_r(ip); BthA[id]=F.Bth[id]+dt*ddt;
    }
    for(size_t ip=Ng+1; ip<Ng+Nr_phys-1; ++ip){ for(size_t kz=Ng;kz<Ng+Nz_phys;++kz){ F.Bth[g.idx(ip,kz)]=BthA[g.idx(ip,Ng)]; } }
    apply_bc_radial(F,cfg,bc);
    std::vector<double> BthB(F.Bth);
    for(size_t ip=Ng+1; ip<Ng+Nr_phys-1; ++ip){
        double r=(int(ip)-int(Ng)+0.5)*g.dr; double eta=eta_profile(r,g,rp);
        size_t id=g.idx(ip,Ng); double ddt=eta*lapl_r(ip); BthB[id]=0.5*(BthA[id] + (F.Bth[id]+dt*ddt));
    }
    for(size_t ip=Ng+1; ip<Ng+Nr_phys-1; ++ip){ for(size_t kz=Ng;kz<Ng+Nz_phys;++kz){ F.Bth[g.idx(ip,kz)]=BthB[g.idx(ip,Ng)]; } }
    apply_bc_radial(F,cfg,bc);
    t += dt;
    if(write_metrics){
        namespace fs=std::filesystem; fs::create_directories(cfg.out_dir + "/debug");
        static bool header=false; std::ofstream fm(cfg.out_dir + "/debug/1d_r_metrics.csv", std::ios::app);
        if(!header){ fm<<"t,dt,cfl,divB_L2,Emag\n"; header=true; }
        double divB=utils::divB_L2(F); double Emag=0.0;
        for(size_t i=0;i<g.size_r();++i){ for(size_t k=0;k<g.size_z();++k){ size_t id=g.idx(i,k); Emag+=0.5*(F.Bth[id]*F.Bth[id]+F.Bz[id]*F.Bz[id]); } }
        fm<<std::setprecision(16)<<t<<","<<dt<<","<<cfg.cfl<<","<<divB<<","<<Emag<<"\n";
    }
}

void initialize(Fields& F, const RunConfig& cfg){ const auto& g=F.g; double r0=0.25*g.Rmax;
    for(size_t i=0;i<g.size_r();++i){ double r=(int(i)-int(g.Ng)+0.5)*g.dr;
        for(size_t k=0;k<g.size_z();++k){ size_t id=g.idx(i,k);
            F.rho[id]=(r<r0)?1.0:0.2; F.p[id]=(r<r0)?1e-2:5e-3; F.Bz[id]=cfg.phys.Bz0;
            F.Bth[id]=(r<r0)? r/r0 : (r>1e-12? r0/r:0.0); F.Br[id]=0.0; F.vr[id]=F.vz[id]=F.vth[id]=0.0; } } }
void apply_sources(Fields& F, const RunConfig& cfg, double){ (void)F;(void)cfg; }
double max_wavespeed(const Fields& F, const RunConfig&){ (void)F; return 1.0; }

} // namespace physics
