#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>
#include <filesystem>

#include "grid.hpp"
#include "state.hpp"
#include "physics.hpp"
#include "utils.hpp"
#include "time_integrator.hpp"
#include "io.hpp"

static std::string slurp(const std::string& path){ std::ifstream f(path); std::stringstream ss; ss << f.rdbuf(); return ss.str(); }
static double read_val(const std::string& s, const std::string& key, double def){
    auto p = s.find(key + ":"); if (p==std::string::npos) return def;
    auto e = s.find("\n", p); std::string line = (e==std::string::npos) ? s.substr(p) : s.substr(p, e-p);
    auto c = line.find(":"); std::string v = line.substr(c+1);
    auto h = v.find('#'); if (h!=std::string::npos) v = v.substr(0,h);
    auto clip=[](int ch){return ch==' '||ch=='\t'||ch=='\r';};
    size_t a=0,b=v.size(); while(a<b&&clip(v[a]))++a; while(b>a&&clip(v[b-1]))--b;
    if (a>=b) return def; try{ return std::stod(v.substr(a,b-a)); } catch(...){ return def; }
}
static int read_ival(const std::string& s, const std::string& key, int def){ return (int)read_val(s,key,def); }
static std::string read_sval(const std::string& s, const std::string& key, const std::string& def){
    auto p = s.find(key + ":"); if (p==std::string::npos) return def;
    auto c = s.find(":", p); auto e = s.find("\n", p);
    std::string v = (e==std::string::npos) ? s.substr(c+1) : s.substr(c+1, e-c-1);
    auto h=v.find('#'); if (h!=std::string::npos) v=v.substr(0,h);
    auto clip=[](int ch){return ch==' '||ch=='\t'||ch=='\r';};
    size_t a=0,b=v.size(); while(a<b&&clip(v[a]))++a; while(b>a&&clip(v[b-1]))--b;
    std::string x = (a<b)? v.substr(a,b-a):std::string();
    if (x.size()>=2 && ((x.front()=='"'&&x.back()=='"')||(x.front()=='\''&&x.back()=='\''))) x=x.substr(1,x.size()-2);
    return x.empty()? def : x;
}

int main(int argc, char** argv){
    if (argc<2){ std::cerr << "Usage: zpinch_run <config.yaml>\n"; return 1; }
    std::string cfgs = slurp(argv[1]);

    int Nr = read_ival(cfgs, "Nr", 256);
    int Nz = read_ival(cfgs, "Nz", 64);
    int Ng = read_ival(cfgs, "ghost", 3);
    double Rmax = read_val(cfgs, "Rmax", 0.01);
    double Zmax = read_val(cfgs, "Zmax", 0.10);
    double t_end = read_val(cfgs, "t_end", 1e-4);
    double cfl = read_val(cfgs, "cfl", 0.4);
    double dt_min = read_val(cfgs, "dt_min", 1e-9);
    int output_every = read_ival(cfgs, "output_every", 25);
    std::string out_dir = read_sval(cfgs, "out_dir", "./data");
    std::string stage = read_sval(cfgs, "stage", "1D_R");

    Grid g(Nr, Nz, Ng, Rmax, Zmax);
    RunConfig rc{g, {}, t_end, cfl, dt_min, output_every, out_dir};
    Fields F(g);

    // Build equilibrium as initial condition
    physics::Equilibrium eq;
    eq.type = read_sval(cfgs, "equilibrium_type", "bennett");
    eq.I0   = read_val(cfgs, "I0", 0.15);
    eq.a    = read_val(cfgs, "a", 0.35);
    eq.r0   = read_val(cfgs, "r0", 0.25);
    eq.p0   = read_val(cfgs, "p0", 1e-2);
    eq.rho0 = read_val(cfgs, "rho0", 1.0);
    physics::build_equilibrium(F, rc, eq);

    if (stage == "0D_EQ"){
        physics::Circuit circ;
        circ.L = read_val(cfgs, "L", 1.0);
        circ.R = read_val(cfgs, "R", 0.1);
        circ.V0= read_val(cfgs, "V0", 1.0);
        circ.shape = read_sval(cfgs, "shape", "step");
        circ.t_pulse = read_val(cfgs, "t_pulse", 0.0);
        double t_end0d = read_val(cfgs, "t_end_0d", 1e-3);
        double dt0d    = read_val(cfgs, "dt_0d",    1e-6);
        physics::solve_LR(circ, t_end0d, dt0d, out_dir);
        std::cout << "[STAGE] 0D_EQ done. Wrote debug to " << out_dir << "/debug/\n";
        return 0;
    }

    if (stage == "1D_R"){
        physics::RadialBC bc;
        bc.axis = read_sval(cfgs, "bc_axis", "regular");
        bc.wall = read_sval(cfgs, "bc_wall", "conducting");
        bc.clamp_Bz_at_wall = (read_sval(cfgs, "clamp_Bz_at_wall", "false")=="true");

        physics::Resistivity rp;
        rp.eta0 = read_val(cfgs, "eta0", 1e-6);
        rp.eta_wall_mult = read_val(cfgs, "eta_wall_mult", 1.0);
        rp.r_wall_frac   = read_val(cfgs, "r_wall_frac", 0.9);

        double eta_max = rp.eta0 * std::max(1.0, rp.eta_wall_mult);
        double dt = std::min(rc.dt_min*10, rc.cfl * g.dr*g.dr / std::max(1e-16, eta_max));
        double t = 0.0; int step = 0;

        namespace fs = std::filesystem; fs::create_directories(out_dir + "/debug");
        { std::ofstream(out_dir + "/debug/1d_r_metrics.csv").close(); }

        while (t < rc.t_end){
            physics::step_1d_r(F, rc, t, dt, bc, rp, true);
            step++;
            if (step % rc.output_every == 0){
                io::write_snapshot(F, rc, step, t);
                io::write_diag(rc.out_dir, step, t, 0.0);
                utils::DebugFrame dbg;
                dbg.t=t; dbg.dt=dt; dbg.cfl=rc.cfl; dbg.max_wave=0.0;
                dbg.divB_L2_val=utils::divB_L2(F);
                dbg.energy_tot=utils::total_energy(F, rc);
                dbg.nan_count=utils::count_nans(F);
                dbg.notes="1D_R checkpoint";
                dbg.write_json(rc.out_dir, step);
                std::cout << "[1D_R] t="<<t<<" step="<<step<<" wrote metrics+snapshot\n";
            }
        }
        std::cout << "[STAGE] 1D_R done. Metrics at " << out_dir << "/debug/1d_r_metrics.csv\n";
        return 0;
    }

    // fallback RUN (toy)
    double t=0.0; int step=0;
    while (t < rc.t_end){
        double max_c = physics::max_wavespeed(F, rc);
        double dt = std::max(rc.dt_min, rc.cfl * std::min(g.dr, g.dz) / (max_c+1e-12));
        timeint::step(F, rc, t, dt);
        t += dt; step++;
        if (step % rc.output_every == 0){
            io::write_snapshot(F, rc, step, t);
            io::write_diag(rc.out_dir, step, t, max_c);
            utils::DebugFrame dbg;
            dbg.t=t; dbg.dt=dt; dbg.cfl=rc.cfl; dbg.max_wave=max_c;
            dbg.divB_L2_val=utils::divB_L2(F);
            dbg.energy_tot=utils::total_energy(F, rc);
            dbg.nan_count=utils::count_nans(F);
            dbg.notes="RUN checkpoint";
            dbg.write_json(rc.out_dir, step);
            std::cout << "[RUN] t="<<t<<" step="<<step<<" snapshot written\n";
        }
    }
    std::cout << "Done at t="<<t<<" after "<<step<<" steps.\n";
    return 0;
}
