
#pragma once
#include "state.hpp"
#include "physics.hpp"
#include <cmath>
#include <algorithm>

namespace modes {

/**
 * Seed a pseudo-3D (theta) perturbation in a 2D (r,z) grid.
 * We imprint a narrow radial band around r0 = r0_frac * Rmax with a Gaussian width
 * sigma = sigma_frac * Rmax, and a sinusoidal dependence in z with wavenumber k (1/m).
 * The azimuthal mode m only affects the radial weighting exponent to roughly mimic
 * steeper structure for larger m: weight ~ (r/r0)^m.
 *
 * eps is a *dimensionless* amplitude relative to local reference (e.g., Bz0 or cs).
 *
 * If seed_vr == true, we add a small radial velocity perturbation.
 * If seed_bth == true, we add a small B_theta perturbation.
 */
inline void seed(Fields& F, const RunConfig& cfg,
                 int m, double k, double eps,
                 double r0_frac, double sigma_frac,
                 bool seed_vr, bool seed_bth)
{
    const Grid& g = F.g;
    const double R0 = r0_frac * g.Rmax;
    const double SIG = std::max(1e-12, sigma_frac * g.Rmax);
    const double Bref = std::max(1e-12, (double)cfg.phys.Bz0);
    const double gam = std::max(1.01,  (double)cfg.phys.gamma);

    // NOTE: RunConfig::phys (SimParams) in your tree exposes pressure0/density0
    // (not p0/rho0). Use them to build a reference sound speed.
    const double p0   = std::max(1e-12, (double)cfg.phys.pressure0);
    const double rho0 = std::max(1e-12, (double)cfg.phys.density0);
    const double cs_ref = std::sqrt(gam * p0 / rho0);

    for (size_t i=0; i<g.size_r(); ++i){
        // cell-centered coordinates
        const double r = (double(int(i) - int(g.Ng)) + 0.5) * g.dr;
        for (size_t kidx=0; kidx<g.size_z(); ++kidx){
            const double z = (double(int(kidx) - int(g.Ng)) + 0.5) * g.dz;
            const size_t id = g.idx(i,kidx);

            // Gaussian ring at r ~ R0
            const double gauss_r = std::exp(-0.5*std::pow((r - R0)/SIG, 2.0));
            // crude radial weight to mimic sharper structure with larger m
            const double radial_weight = std::pow(std::max(1e-6, r / std::max(1e-6, R0)), std::max(0, m));
            const double envelope = gauss_r * radial_weight;

            // z sinusoid
            const double phase = k * z;   // cos(k z)
            const double s = std::cos(phase);

            if (seed_vr){
                const double dv = eps * cs_ref * envelope * s;
                F.vr[id] += dv;
            }
            if (seed_bth){
                const double dB = eps * Bref * envelope * s;
                F.Bth[id] += dB;
            }
        }
    }
}

} // namespace modes
